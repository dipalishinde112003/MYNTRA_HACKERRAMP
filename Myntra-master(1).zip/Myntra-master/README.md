🛍️ Myntra Clone: E-commerce website inspired by Myntra, offering a wide range of fashion and lifestyle products. Built from scratch. Features user authentication, product catalog, shopping cart, and more. Designed for responsive and intuitive user experience.





![image](https://user-images.githubusercontent.com/77974484/161418508-820faf68-9cea-4570-9fe5-6fe50085a908.png)





![image](https://user-images.githubusercontent.com/77974484/161418568-fb6db3cb-47c9-4911-b486-0648ef79ceb3.png)

![image](https://user-images.githubusercontent.com/77974484/161418579-9ec6c7b1-8474-4c21-8927-04800e9c0804.png)





![image](https://user-images.githubusercontent.com/77974484/161418616-0103de9b-804e-403e-b59b-16bd4f012dc8.png)

![image](https://user-images.githubusercontent.com/77974484/161418629-2f55ef0c-c323-4bd0-86ec-2d04092e4af0.png)




![image](https://user-images.githubusercontent.com/77974484/161418666-9f75ebdd-a6e4-470e-8190-8699b6dd64b4.png)

![image](https://user-images.githubusercontent.com/77974484/161418677-6aa9fb78-083b-4986-b774-5b74b44b157f.png)



![image](https://user-images.githubusercontent.com/77974484/161418767-c17d11ce-3a7d-4f2d-9abe-b2ac1ab0e1bd.png)





![image](https://user-images.githubusercontent.com/77974484/161418840-a913c3ff-e219-4ec0-9467-4320cd787eb0.png)




![image](https://user-images.githubusercontent.com/77974484/161418887-c30e9832-e415-4de7-bc24-f5e83f4605a0.png)


![image](https://user-images.githubusercontent.com/77974484/161433073-291a3727-c191-42ad-be92-dd453264de10.png)
















