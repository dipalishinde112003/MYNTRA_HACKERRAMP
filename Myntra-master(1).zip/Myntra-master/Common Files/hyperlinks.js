
document.querySelector('.fa_user').addEventListener('click', function(){
    window.location.href = "../Profile/profile.html"
})
// HYPERLINKS
document.querySelector('.fa-heart').addEventListener('click', function(){
    window.location.href = "../wishlist/wishlist.html"
})
document.querySelector(".fa_wishlist").addEventListener('click', function(){
    window.location.href = "../wishlist/wishlist.html"
})
document.querySelector('.fa-bag-shopping').addEventListener('click', function(){
    window.location.href = "../wishlist/cart.html"
})
document.querySelector('.fa_cart').addEventListener('click', function(){
    window.location.href = "../wishlist/cart.html"
})
